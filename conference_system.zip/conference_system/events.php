<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conference_system";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM Event";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #009879;
            color: white;
        }
        a.register {
            background-color: #009879;
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<h2>Available Conferences & Workshops</h2>

<table>
    <tr>
        <th>Title</th>
        <th>Date</th>
        <th>Location</th>
        <th>Capacity</th>
        <th>Action</th>
    </tr>

<?php
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["Title"] . "</td>
                <td>" . $row["Date"] . "</td>
                <td>" . $row["Location"] . "</td>
                <td>" . $row["Capacity"] . "</td>
                <td><a class='register' href='register.php?event_id=" . $row["EventID"] . "'>Register</a></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No events available</td></tr>";
}
$conn->close();
?>

</table>

</body>
</html>
