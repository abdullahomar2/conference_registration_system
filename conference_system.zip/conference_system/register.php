<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conference_system";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_GET['event_id'])) {
    $eventID = $_GET['event_id'];
} else {
    die("No event selected.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullName = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $sql_user = "INSERT INTO User (FullName, Email, Phone) VALUES ('$fullName', '$email', '$phone')";

    if ($conn->query($sql_user) === TRUE) {

        $userID = $conn->insert_id;

        $sql_register = "INSERT INTO Registration (UserID, EventID, RegistrationDate)
                         VALUES ('$userID', '$eventID', CURDATE())";

        if ($conn->query($sql_register) === TRUE) {

            echo "<p style='color: green; text-align: center;'>Registration successful! You have been registered for the event.</p>";

            header("refresh:3;url=events.php");
        } else {
            echo "<p style='color: red; text-align: center;'>Error: " . $sql_register . "<br>" . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color: red; text-align: center;'>Error: " . $sql_user . "<br>" . $conn->error . "</p>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
  
    <title>Register for Event</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            text-align: center;
        }
        .form-container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .form-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .form-container input[type="submit"] {
            background-color: #009879;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<h2>Register for the Event</h2>

<div class="form-container">
    <form method="post" action="">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone" required>
        <input type="submit" value="Register">
    </form>
</div>

</body>
</html>
